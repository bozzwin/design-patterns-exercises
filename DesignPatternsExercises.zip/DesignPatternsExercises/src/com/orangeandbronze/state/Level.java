package com.orangeandbronze.state;

public enum Level {
	JUNIOR_ASSOCIATE, SENIOR_ASSOCIATE, JUNIOR_PARTNER, SENIOR_PARTNER
}
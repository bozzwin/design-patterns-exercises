package com.orangeandbronze.state;

import java.math.BigDecimal;

public class Company {
	static BigDecimal getProfit() {
		return new BigDecimal("10000000.00");
	}
}

package com.orangeandbronze.strategy;

enum FileFormat {
	XML, CSV
}